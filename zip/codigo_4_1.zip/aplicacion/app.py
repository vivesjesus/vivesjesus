
from flask import Flask
from flask.cli import FlaskGroup

app = Flask(__name__)	

@app.route('/')
def inicio():
    return 'Página principal'	

@app.route('/articulos/')
def articulos():
    return 'Lista de artículos'	

@app.route('/acercade')
def acercade():
    return 'Página acerca de...'

@app.route("/articulos/<int:id>")
def mostrar_ariculo(id):
    return 'Vamos a mostrar el artículo con id:{id}'

@app.route("/hello/")
@app.route("/hello/<string:nombre>")
@app.route("/hello/<string:nombre>/<int:edad>")
def hola(nombre=None,edad=None):
    if nombre and edad:
        return 'Hola, {nombre} tienes {edad} años.'
    elif nombre:
        return 'Hola, {nombre}'.format(nombre)
    else:
        return 'Hola mundo'

