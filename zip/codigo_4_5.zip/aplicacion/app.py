from flask import Flask, request, make_response, abort, redirect, url_for
from flask.cli import FlaskGroup

app = Flask(__name__)	

@app.route('/')
def inicio():
    return '<img src="'+url_for('static', filename='img/tux.png')+'"/>'

# @app.route('/')
# def index():
#     return redirect(url_for('return_string'))

# @app.route('/')
# def inicio():
#     return 'Página principal'	

@app.route('/articulos/')
def articulos():
    return 'Lista de artículos'	

@app.route('/acercade')
def acercade():
    return 'Página acerca de...'

@app.route("/articulos/<int:id>")
def mostrar_ariculo(id):
    return 'Vamos a mostrar el artículo con id:{id}'

@app.route("/hello/")
@app.route("/hello/<string:nombre>")
@app.route("/hello/<string:nombre>/<int:edad>")
def hola(nombre=None,edad=None):
    if nombre and edad:
        return 'Hola, {nombre} tienes {edad} años.'
    elif nombre:
        return 'Hola, {nombre}'.format(nombre)
    else:
        return 'Hola mundo'


@app.route('/articulos/new',methods=["POST"])
def articulos_new():
    return 'Está URL recibe información de un formulario con el método POST'

@app.route('/login')
def login():
	abort(401)
	# Esta línea no se ejecuta


@app.route('/string/')
def return_string():
    return 'Hello, world!'	

@app.route('/object/')
def return_object():
    headers = {'Content-Type': 'text/plain'}
    return make_response('Hello, world!', 200,headers)	

@app.route('/tuple/')
def return_tuple():
    return 'Hello, world!', 200, {'Content-Type':'text/plain'}


@app.errorhandler(404)
def page_not_found(error):
    return 'Página no encontrada...', 404