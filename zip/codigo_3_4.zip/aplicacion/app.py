
from flask import Flask
from flask.cli import FlaskGroup

app = Flask(__name__)	

@app.route('/')
def inicio():
    return 'Página principal'	

@app.route('/articulos/')
def articulos():
    return 'Lista de artículos'	

@app.route('/acercade')
def acercade():
    return 'Página acerca de...'